document.getElementById("btn-titulo").addEventListener("click",()=>
{
  const titulo =
        document.getElementById("titulo");
  titulo.textContent = "¡Hola amiguitos de yutub!";
}
);


document.getElementById("btn-cajas").addEventListener("click",()=>
{
  const cajas =
        document.getElementsByClassName("caja");
  for (let i = 0; i < cajas.length; i++)
    {
      cajas[i].style.backgroundColor = "blue";
    }
}                                                     
);


document.getElementById("btn-primera").addEventListener("click",()=>
{
  const primeracaja =
        document.querySelector(".caja");
  primeracaja.style.backgroundColor = "red";
}                                                       
);


document.getElementById("btn-bordes").addEventListener("click",()=>
{
  const cajas =
        document.querySelectorAll(".caja");
  cajas.forEach(caja=>{
    caja.style.border = "2px solid green"
  });
}                                                      
);