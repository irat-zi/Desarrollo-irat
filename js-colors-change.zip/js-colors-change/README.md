# JS-colors change

A Pen created on CodePen.

Original URL: [https://codepen.io/IRATZE-FLORESGONZALEZ/pen/KwdJZaQ](https://codepen.io/IRATZE-FLORESGONZALEZ/pen/KwdJZaQ).

